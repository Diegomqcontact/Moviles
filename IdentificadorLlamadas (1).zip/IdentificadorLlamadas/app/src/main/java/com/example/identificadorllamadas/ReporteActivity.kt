package com.example.identificadorllamadas

import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import androidx.appcompat.app.AlertDialog

class ReporteActivity : AppCompatActivity() {

    private lateinit var editTextNumero: TextView
    private lateinit var editTextComentario: EditText
    private lateinit var radioGroupTipo: RadioGroup
    private lateinit var buttonGuardarReporte: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reporte)

        editTextNumero = findViewById(R.id.editTextNumero)
        editTextComentario = findViewById(R.id.editTextComentario)
        radioGroupTipo = findViewById(R.id.radioGroupTipo)
        buttonGuardarReporte = findViewById(R.id.buttonGuardarReporte)
        val textViewContador = findViewById<TextView>(R.id.textViewContador)

        // Bloquear edición del número y mostrarlo
        val numeroDetectado = intent.getStringExtra("numero_detectado")
        editTextNumero.setText(numeroDetectado)
        editTextNumero.isEnabled = false

        val db = Firebase.firestore
        val auth = FirebaseAuth.getInstance()

        buttonGuardarReporte.setOnClickListener {
            val numero = editTextNumero.text.toString()
            val comentario = editTextComentario.text.toString()

            // Obtener texto del RadioButton seleccionado
            val selectedId = radioGroupTipo.checkedRadioButtonId
            if (selectedId == -1) {
                Toast.makeText(this, "Selecciona un tipo de reporte", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val radioButton = findViewById<RadioButton>(selectedId)
            val tipoReporte = radioButton.text.toString()

            if (numero.isEmpty()) {
                Toast.makeText(this, "Número no válido", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val nuevoReporte = hashMapOf(
                "numero" to numero,
                "tipo_reporte" to tipoReporte,
                "comentario" to comentario,
                "userId" to Firebase.auth.currentUser?.uid,
                "fecha_reporte" to com.google.firebase.firestore.FieldValue.serverTimestamp()
            )

            val userId = auth.currentUser?.uid
            if (userId != null) {
                db.collection("reportes")
                    .document(userId)
                    .collection("mis_reportes")
                    .add(nuevoReporte)
                    .addOnSuccessListener {
                        //Toast.makeText(this, "Reporte guardado exitosamente", Toast.LENGTH_SHORT).show()

                        val builder = AlertDialog.Builder(this)
                        builder.setTitle("Éxito")
                        builder.setMessage("Reporte guardado exitosamente")
                        builder.setPositiveButton("Aceptar") { dialog, _ ->
                            dialog.dismiss()
                            finish() // Cierra la actividad después de que el usuario da clic en aceptar
                        }
                        builder.setCancelable(false)
                        builder.show()

                        // Guardar número reportado en preferencias
                        val prefs = getSharedPreferences("ReportesPrefs", MODE_PRIVATE)
                        prefs.edit().putBoolean(numero, true).apply()

                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(this, "Error al guardar: ${e.message}", Toast.LENGTH_LONG).show()
                    }
            } else {
                Toast.makeText(this, "Usuario no autenticado", Toast.LENGTH_SHORT).show()
            }
        }

        // Mostrar cantidad de reportes del número
        val usuarioActual = Firebase.auth.currentUser
        if (usuarioActual != null && !numeroDetectado.isNullOrEmpty()) {
            db.collectionGroup("mis_reportes")
                .whereEqualTo("numero", numeroDetectado)
                .get()
                .addOnSuccessListener { querySnapshot ->
                    val cantidad = querySnapshot.size()
                    textViewContador.text = "* Este número ha sido reportado $cantidad veces."
                }
                .addOnFailureListener { e ->
                    textViewContador.text = "Error: ${e.message}"
                    Log.e("FIRESTORE_ERROR", "Error al consultar reportes", e)
                }
        } else {
            textViewContador.text = "No se pudo verificar la cantidad: usuario no autenticado"
        }
    }
}
