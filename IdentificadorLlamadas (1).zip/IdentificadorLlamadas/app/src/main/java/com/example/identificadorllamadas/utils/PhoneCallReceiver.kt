package com.example.identificadorllamadas.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import com.example.identificadorllamadas.MainActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class PhoneCallReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
        if (state == TelephonyManager.EXTRA_STATE_RINGING) {
            val incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)

            if (incomingNumber != null && !isNumberInContacts(context, incomingNumber)) {
                try {
                    FirebaseApp.initializeApp(context)
                } catch (_: Exception) {
                }

                val db = Firebase.firestore
                db.collectionGroup("mis_reportes")
                    .whereEqualTo("numero", incomingNumber)
                    .get()
                    .addOnSuccessListener { querySnapshot ->
                        val cantidad = querySnapshot.size()
                        mostrarNotificacion(context, incomingNumber, cantidad)
                        enviarBroadcastActualizacion(context, incomingNumber)

                    }
                    .addOnFailureListener {
                        // Puedes ignorar si falla o mostrar una notificación genérica si quieres
                    }
            }
        }
    }

    private fun isNumberInContacts(context: Context, number: String): Boolean {
        val resolver = context.contentResolver
        val uri = android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val cursor = resolver.query(
            uri,
            arrayOf(android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER),
            null,
            null,
            null
        )

        cursor?.use {
            while (it.moveToNext()) {
                val contactNumber = it.getString(0).replace("\\s".toRegex(), "")
                if (contactNumber.contains(number.takeLast(7))) {
                    return true
                }
            }
        }
        return false
    }


    private fun mostrarNotificacion(context: Context, numero: String, cantidad: Int) {
        val channelId = "canal_reportes"
        val mensaje = "Número desconocido: $numero ha sido reportado $cantidad veces."

        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Reportes de llamadas",
                NotificationManager.IMPORTANCE_HIGH
            )
            notificationManager.createNotificationChannel(channel)
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            putExtra("incoming_number", numero)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Número reportado detectado")
            .setContentText(mensaje)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(1001, notification)
    }

    private fun enviarBroadcastActualizacion(context: Context, numero: String) {
        val intent = Intent("com.example.identificadorllamadas.NUEVA_LLAMADA")
        intent.putExtra("incoming_number", numero)
        context.sendBroadcast(intent)
    }

}