package com.example.identificadorllamadas.data

import android.content.Context
import android.content.SharedPreferences
import com.example.identificadorllamadas.entidad.Llamada
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class LlamadasRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("LlamadasPrefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    /**
     * Carga la lista de llamadas desde SharedPreferences.
     */
    fun cargar(): MutableList<Llamada> {
        val json = prefs.getString("llamadas", "[]")
        val type = object : TypeToken<MutableList<Llamada>>() {}.type
        return gson.fromJson(json, type)
    }

    /**
     * Guarda la lista de llamadas en SharedPreferences.
     */
    fun guardar(llamadas: List<Llamada>) {
        val json = gson.toJson(llamadas)
        prefs.edit().putString("llamadas", json).apply()
    }


}
