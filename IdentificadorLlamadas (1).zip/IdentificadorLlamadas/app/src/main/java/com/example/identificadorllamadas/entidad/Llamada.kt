package com.example.identificadorllamadas.entidad

data class Llamada(
    val numero: String,
    val timestamp: Long = System.currentTimeMillis()
)