package com.example.identificadorllamadas

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.identificadorllamadas.entidad.Llamada
import java.text.SimpleDateFormat
import java.util.*

class LlamadaAdapter(
    private val context: Context,
    private var llamadas: MutableList<Llamada> // Cambiamos esto a MutableList
) : RecyclerView.Adapter<LlamadaAdapter.LlamadaViewHolder>() {

    // SharedPreferences para registrar llamadas ya reportadas
    private val prefs = context.getSharedPreferences("ReportesPrefs", Context.MODE_PRIVATE)

    // ViewHolder para el item de llamada
    inner class LlamadaViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val numeroLlamada: TextView = view.findViewById(R.id.numeroLlamada)
        val btnReportar: Button = view.findViewById(R.id.btnReportar)
        val btnVerDetalle: TextView = view.findViewById(R.id.btnVerDetalle)
        val numeroText: TextView = itemView.findViewById(R.id.numeroLlamada)
        val fechaHoraText: TextView = itemView.findViewById(R.id.fechaHoraLlamada)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LlamadaViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_llamada, parent, false)
        return LlamadaViewHolder(view)
    }

    override fun onBindViewHolder(holder: LlamadaViewHolder, position: Int) {
        val llamada = llamadas[position]
        val numero = llamada.numero

        // Mostrar número de teléfono
        holder.numeroLlamada.text = numero

        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault())
        val fechaHora = sdf.format(Date(llamada.timestamp))
        holder.fechaHoraText.text = fechaHora

        // Verifica si el número ya fue reportado
        val yaReportado = prefs.getBoolean(numero, false)

        // Configura el botón de reporte
        holder.btnReportar.apply {
            isEnabled = !yaReportado
            text = if (yaReportado) "Reportado" else "Reportar"
            backgroundTintList = ContextCompat.getColorStateList(
                context,
                if (yaReportado) R.color.colorPlomo else R.color.colorAzul
            )
            setOnClickListener {
                // Lanzar actividad de reporte con el número
                val intent = Intent(context, ReporteActivity::class.java)
                intent.putExtra("numero_detectado", numero)
                context.startActivity(intent)
            }
        }

        // Configura botón de ver detalle
        holder.btnVerDetalle.setOnClickListener {
            val intent = Intent(context, DetalleLlamadaActivity::class.java)
            intent.putExtra("numero", numero)
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int = llamadas.size

    // Metodo para agregar o actualizar una llamada
    fun agregarOActualizarLlamada(llamada: Llamada) {
        val index = llamadas.indexOfFirst { it.numero == llamada.numero }

        if (index != -1) {
            // Removemos la anterior
            llamadas.removeAt(index)
            notifyItemRemoved(index)
        }

        // Agregamos al inicio con el nuevo timestamp
        llamadas.add(0, llamada)
        notifyItemInserted(0)
    }

    fun obtenerLlamadas(): List<Llamada> {
        return llamadas.toList()
    }


}
