package com.example.identificadorllamadas

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.identificadorllamadas.data.LlamadasRepository
import com.example.identificadorllamadas.entidad.Llamada
import com.example.identificadorllamadas.utils.PermissionManager
import com.google.firebase.FirebaseApp

class MainActivity : AppCompatActivity() {

    private val PERMISSIONS_REQUEST_CODE = 1

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: LlamadaAdapter
    private lateinit var repository: LlamadasRepository

    private val llamadasList = mutableListOf<Llamada>()

    private val callReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val numero = intent?.getStringExtra("incoming_number")
            numero?.let {
                val nuevaLlamada = Llamada(numero)

                // Usamos la función para agregar o actualizar la llamada en el adaptador
                adapter.agregarOActualizarLlamada(nuevaLlamada)
                repository.guardar(adapter.obtenerLlamadas())
                recyclerView.scrollToPosition(0)

            }
        }
    }

    private val permissions = arrayOf(
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.READ_CALL_LOG,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.POST_NOTIFICATIONS // Android 13+
    )

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        FirebaseApp.initializeApp(this)

        repository = LlamadasRepository(this)

        // Configura RecyclerView
        recyclerView = findViewById(R.id.recyclerViewLlamadas)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = LlamadaAdapter(this, llamadasList)
        recyclerView.adapter = adapter

        // Verifica permisos
        if (!PermissionManager.hasPermissions(this, permissions)) {
            PermissionManager.requestPermissions(this, permissions, PERMISSIONS_REQUEST_CODE)
        }

        // Carga llamadas almacenadas
        llamadasList.addAll(repository.cargar())

        // Si MainActivity se abre con número desde notificación
        intent.getStringExtra("incoming_number")?.let { numero ->
            if (llamadasList.none { it.numero == numero }) {
                val nueva = Llamada(numero)
                llamadasList.add(0, nueva)
                repository.guardar(llamadasList)
                adapter.notifyItemInserted(0)
            }
        }

        // Registro seguro del BroadcastReceiver
        val filter = IntentFilter("com.example.identificadorllamadas.NUEVA_LLAMADA")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(callReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(callReceiver, filter)
        }

    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSIONS_REQUEST_CODE) {
            if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                Toast.makeText(this, "Permisos concedidos", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Debes aceptar permisos para funcionar", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        adapter.notifyDataSetChanged()
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(callReceiver)
    }
}
